<?php
header('Content-Type: application/json');
session_start();
require_once 'db_connect.php';

$action = $_POST['action'];
if ($action === 'login') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sql = "SELECT id, password, role FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        echo json_encode(['success' => true, 'message' => 'Успішний вхід!', 'user_id' => $user['id'], 'role' => $user['role']]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Невірний email або пароль!']);
    }
} elseif ($action === 'register') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role = 'participant';
    $sql = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $email, $password, $role);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Реєстрація успішна!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Помилка реєстрації!']);
    }
}

$conn->close();
?>