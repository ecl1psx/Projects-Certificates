<?php
header('Content-Type: application/json');
require_once 'db_connect.php';

$userId = $_GET['userId'] ?? null;
if ($userId === null) {
    echo json_encode(['error' => 'User ID not provided']);
    $conn->close();
    exit;
}

$userSql = "SELECT name, email FROM users WHERE id = ?";
$userStmt = $conn->prepare($userSql);
$userStmt->bind_param("i", $userId);
$userStmt->execute();
$userResult = $userStmt->get_result();
$user = $userResult->fetch_assoc();

if (!$user) {
    echo json_encode(['error' => 'User not found']);
    $conn->close();
    exit;
}

$updateSql = "UPDATE bookings b
              JOIN events e ON b.eventId = e.id
              SET b.status = 'confirmed'
              WHERE b.userId = ? AND b.status = 'pending' AND e.date < NOW()";
$updateStmt = $conn->prepare($updateSql);
$updateStmt->bind_param("i", $userId);
$updateStmt->execute();

$bookingsSql = "SELECT b.id, b.eventId, e.title AS eventTitle, e.date, b.places, b.status, b.createdAt
                FROM bookings b
                LEFT JOIN events e ON b.eventId = e.id
                WHERE b.userId = ?
                ORDER BY b.createdAt DESC";
$bookingsStmt = $conn->prepare($bookingsSql);
$bookingsStmt->bind_param("i", $userId);
$bookingsStmt->execute();
$bookingsResult = $bookingsStmt->get_result();

$bookings = [];
while ($row = $bookingsResult->fetch_assoc()) {
    $bookings[] = $row;
}

$response = [
    'name' => $user['name'],
    'email' => $user['email'],
    'bookings' => $bookings
];
echo json_encode($response);

$conn->close();
?>