<?php
header('Content-Type: application/json');
require_once 'db_connect.php';

$sql = "SELECT id, name FROM sport_types";
$result = $conn->query($sql);
$sportTypes = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($sportTypes);
$conn->close();
?>