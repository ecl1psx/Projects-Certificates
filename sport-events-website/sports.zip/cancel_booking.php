<?php
header('Content-Type: application/json');
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Не авторизовано']);
    $conn->close();
    exit;
}

$bookingId = $_POST['bookingId'] ?? null;
$places = $_POST['places'] ?? 0;
if ($bookingId === null) {
    echo json_encode(['success' => false, 'message' => 'ID бронювання не вказано']);
    $conn->close();
    exit;
}

$sqlCheck = "SELECT userId, eventId FROM bookings WHERE id = ? AND userId = ?";
$stmtCheck = $conn->prepare($sqlCheck);
$stmtCheck->bind_param("ii", $bookingId, $_SESSION['user_id']);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();
$booking = $resultCheck->fetch_assoc();

if (!$booking) {
    echo json_encode(['success' => false, 'message' => 'Бронювання не знайдено або не належить вам']);
    $conn->close();
    exit;
}

$sqlEvent = "UPDATE events e JOIN bookings b ON e.id = b.eventId SET e.availablePlaces = e.availablePlaces + ? WHERE b.id = ?";
$stmtEvent = $conn->prepare($sqlEvent);
$stmtEvent->bind_param("ii", $places, $bookingId);

$sqlDelete = "DELETE FROM bookings WHERE id = ? AND userId = ?";
$stmtDelete = $conn->prepare($sqlDelete);
$stmtDelete->bind_param("ii", $bookingId, $_SESSION['user_id']);

$conn->begin_transaction();
try {
    $stmtEvent->execute();
    $stmtDelete->execute();
    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Бронювання скасовано']);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Помилка при скасуванні: ' . $e->getMessage()]);
}

$conn->close();
?>