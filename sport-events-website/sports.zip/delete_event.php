<?php
header('Content-Type: application/json');
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'administrator') {
    echo json_encode(['success' => false, 'message' => 'Доступ заборонено!']);
    exit;
}

$id = (int)$_POST['id'];

$checkSql = "SELECT id FROM bookings WHERE eventId = ? AND status = 'pending'";
$checkStmt = $conn->prepare($checkSql);
$checkStmt->bind_param("i", $id);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Неможливо видалити захід із активними бронюваннями!']);
    exit;
}

$sql = "DELETE FROM events WHERE id = ? AND organizerId = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id, $_SESSION['user_id']);
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Захід видалено!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Помилка видалення заходу!']);
}

$conn->close();
?>