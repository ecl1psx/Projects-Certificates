<?php
header('Content-Type: application/json');
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Будь ласка, увійдіть!']);
    exit;
}

$eventId = $_POST['eventId'];
$name = $_POST['name'];
$contact = $_POST['contact'];
$places = (int)$_POST['places'];
$comments = $_POST['comments'];
$userId = $_SESSION['user_id'];

$sql = "SELECT availablePlaces FROM events WHERE id = ? AND status = 'approved'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $eventId);
$stmt->execute();
$result = $stmt->get_result();
$event = $result->fetch_assoc();

if ($event && $event['availablePlaces'] >= $places) {
    $newAvailable = $event['availablePlaces'] - $places;
    $updateSql = "UPDATE events SET availablePlaces = ? WHERE id = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("ii", $newAvailable, $eventId);
    $updateStmt->execute();

    $insertSql = "INSERT INTO bookings (eventId, userId, places, contact, comments) VALUES (?, ?, ?, ?, ?)";
    $insertStmt = $conn->prepare($insertSql);
    $insertStmt->bind_param("iiiss", $eventId, $userId, $places, $contact, $comments);
    $insertStmt->execute();

    echo json_encode(['success' => true, 'message' => 'Бронювання успішне!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Недостатньо місць або захід недоступний!']);
}

$conn->close();
?>