<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "sports_db";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Помилка підключення до бази даних: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>