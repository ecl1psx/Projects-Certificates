<?php
header('Content-Type: application/json');
require_once 'db_connect.php';

$sportType = $_GET['sportType'] ?? '';
$date = $_GET['date'] ?? '';

$sql = "SELECT e.id, e.title, st.name AS sportType, e.date, e.location, e.availablePlaces, e.description, e.conditions, e.organizerContact, e.sportTypeId
        FROM events e JOIN sport_types st ON e.sportTypeId = st.id
        WHERE 1=1";
$params = [];
$types = '';

if ($sportType !== '') {
    $sql .= " AND st.name = ?";
    $params[] = $sportType;
    $types .= 's';
}

if ($date !== '') {
    $sql .= " AND DATE(e.date) = ?";
    $params[] = $date;
    $types .= 's';
}

$stmt = $conn->prepare($sql);
if ($types !== '') {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$events = [];

while ($row = $result->fetch_assoc()) {
    $events[] = $row;
}

echo json_encode($events);
$conn->close();
?>