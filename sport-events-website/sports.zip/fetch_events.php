<?php
header('Content-Type: application/json');
require_once 'db_connect.php';

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 5;
$offset = ($page - 1) * $perPage;

$sql = "SELECT e.id, e.title, st.name AS sportType, e.date, e.location, e.description, e.availablePlaces
        FROM events e JOIN sport_types st ON e.sportTypeId = st.id WHERE e.status = 'approved' LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $perPage, $offset);
$stmt->execute();
$result = $stmt->get_result();
$events = $result->fetch_all(MYSQLI_ASSOC);

$totalSql = "SELECT COUNT(*) FROM events WHERE status = 'approved'";
$totalResult = $conn->query($totalSql);
$total = $totalResult->fetch_row()[0];

echo json_encode(['events' => $events, 'total' => $total]);
$conn->close();
?>