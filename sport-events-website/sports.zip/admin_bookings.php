<?php
header('Content-Type: application/json');
require_once 'db_connect.php';

$sql = "SELECT b.id, e.title AS eventTitle, u.name AS userName, b.contact, b.places, b.status, b.createdAt
        FROM bookings b
        JOIN events e ON b.eventId = e.id
        JOIN users u ON b.userId = u.id
        ORDER BY b.createdAt DESC";
$result = $conn->query($sql);
$bookings = [];

while ($row = $result->fetch_assoc()) {
    $bookings[] = $row;
}

echo json_encode($bookings);
$conn->close();
?>