<?php
header('Content-Type: application/json');
session_start();
require_once 'db_connect.php';

try {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'administrator') {
        echo json_encode(['success' => false, 'message' => 'Доступ заборонено']);
        exit;
    }

    $organizerId = $_SESSION['user_id'];

    $title = $_POST['title'] ?? '';
    $sportTypeId = $_POST['sportTypeId'] ?? null;
    $date = $_POST['date'] ?? '';
    $location = $_POST['location'] ?? '';
    $description = $_POST['description'] ?? '';
    $conditions = $_POST['conditions'] ?? '';
    $organizerContact = $_POST['organizerContact'] ?? '';
    $maxPlaces = $_POST['maxPlaces'] ?? 0;
    $availablePlaces = $maxPlaces;
    $status = 'approved';

    if (empty($title) || $sportTypeId === null || empty($date) || empty($location) || $maxPlaces <= 0) {
        echo json_encode(['success' => false, 'message' => 'Недостатньо даних для створення заходу']);
        exit;
    }

    $checkSql = "SELECT id FROM sport_types WHERE id = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("i", $sportTypeId);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Тип спорту не знайдено']);
        exit;
    }

    $insertSql = "INSERT INTO events (title, sportTypeId, date, location, description, conditions, organizerContact, maxPlaces, availablePlaces, organizerId, status)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertSql);
    $stmt->bind_param("sissssiiiss", $title, $sportTypeId, $date, $location, $description, $conditions, $organizerContact, $maxPlaces, $availablePlaces, $organizerId, $status);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Захід створено успішно']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Помилка створення заходу: ' . $conn->error]);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Помилка: ' . $e->getMessage()]);
}

$conn->close();
?>