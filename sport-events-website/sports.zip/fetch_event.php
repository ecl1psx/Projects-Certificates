<?php
header('Content-Type: application/json');
require_once 'db_connect.php';

$eventId = $_GET['eventId'] ?? null;
if ($eventId === null) {
    echo json_encode([]);
    $conn->close();
    exit;
}

$sql = "SELECT e.id, e.title, st.name AS sportType, e.date, e.location, e.availablePlaces, e.description, e.conditions, e.organizerContact
        FROM events e JOIN sport_types st ON e.sportTypeId = st.id WHERE e.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $eventId);
$stmt->execute();
$result = $stmt->get_result();
$event = $result->fetch_assoc();

if (!$event) {
    echo json_encode([]);
} else {
    echo json_encode($event);
}
$conn->close();
?>