document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const loginMessage = document.getElementById('loginMessage');
    const registerMessage = document.getElementById('registerMessage');
    const authNavItem = document.getElementById('authNavItem');
    const backButton = document.getElementById('backButton');

    function updateAuthButton() {
        const userId = sessionStorage.getItem('user_id');
        authNavItem.innerHTML = userId ?
            '<button id="logoutButton" class="btn btn-danger nav-link">Вийти</button>' :
            '<a class="nav-link active" href="../auth.html">Увійти/Зареєструватися</a>';
    }

    authNavItem.addEventListener('click', (e) => {
        if (e.target.id === 'logoutButton') {
            sessionStorage.removeItem('user_id');
            sessionStorage.removeItem('role');
            window.location.href = '../index.html';
        }
    });

    backButton.addEventListener('click', () => {
        window.history.back();
    });

    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;

        fetch('../auth.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=login&email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`
        })
            .then(response => response.json())
            .then(data => {
                loginMessage.innerHTML = `<div class="alert ${data.success ? 'alert-success' : 'alert-danger'}">${data.message}</div>`;
                if (data.success) {
                    sessionStorage.setItem('user_id', data.user_id);
                    sessionStorage.setItem('role', data.role);
                    if (data.role === 'administrator') {
                        setTimeout(() => window.location.href = '../admin.html', 2000);
                    } else {
                        setTimeout(() => window.location.href = '../index.html', 2000);
                    }
                }
            });
    });

    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('registerName').value;
        const email = document.getElementById('registerEmail').value;
        const password = document.getElementById('registerPassword').value;

        fetch('../auth.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=register&name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`
        })
            .then(response => response.json())
            .then(data => {
                registerMessage.innerHTML = `<div class="alert ${data.success ? 'alert-success' : 'alert-danger'}">${data.message}</div>`;
                if (data.success) {
                    setTimeout(() => window.location.href = '../auth.html#login', 2000);
                }
            });
    });

    updateAuthButton();
});