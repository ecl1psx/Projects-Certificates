document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const eventId = urlParams.get('eventId');
    const eventDetails = document.getElementById('eventDetails');
    const bookingForm = document.getElementById('bookingForm');
    const authMessage = document.getElementById('authMessage');
    const message = document.getElementById('message');
    const authNavItem = document.getElementById('authNavItem');
    const backButton = document.getElementById('backButton');

    function updateAuthButton() {
        const userId = sessionStorage.getItem('user_id');
        authNavItem.innerHTML = userId ?
            '<button id="logoutButton" class="btn btn-danger nav-link">Вийти</button>' :
            '<a class="nav-link" href="../auth.html">Увійти/Зареєструватися</a>';
    }

    authNavItem.addEventListener('click', (e) => {
        if (e.target.id === 'logoutButton') {
            sessionStorage.removeItem('user_id');
            sessionStorage.removeItem('role');
            window.location.href = '../index.html';
        }
    });

    backButton.addEventListener('click', () => {
        window.history.back();
    });

    fetch(`../fetch_event.php?eventId=${eventId}`)
        .then(response => {
            if (!response.ok) throw new Error('Помилка при отриманні даних');
            return response.json();
        })
        .then(data => {
            if (!data || Object.keys(data).length === 0) {
                eventDetails.innerHTML = '<div class="alert alert-danger">Захід не знайдено.</div>';
                return;
            }
            eventDetails.innerHTML = `
                <h3>${data.title}</h3>
                <p>Тип: ${data.sportType}</p>
                <p>Дата: ${new Date(data.date).toLocaleString('uk-UA')}</p>
                <p>Місце: ${data.location}</p>
                <p>Доступні місця: ${data.availablePlaces}</p>
            `;
            if (data.availablePlaces <= 0) {
                message.innerHTML = '<div class="alert alert-danger">Місць немає!</div>';
            } else if (!sessionStorage.getItem('user_id')) {
                authMessage.style.display = 'block';
            } else {
                bookingForm.style.display = 'block';
            }
        })
        .catch(error => {
            console.error('Помилка:', error);
            eventDetails.innerHTML = '<div class="alert alert-danger">Помилка завантаження даних.</div>';
        });

    bookingForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!sessionStorage.getItem('user_id')) {
            message.innerHTML = '<div class="alert alert-danger">Будь ласка, увійдіть!</div>';
            return;
        }
        const name = document.getElementById('name').value;
        const contact = document.getElementById('contact').value;
        const places = parseInt(document.getElementById('places').value);
        const comments = document.getElementById('comments').value;

        fetch('../book.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `eventId=${eventId}&name=${encodeURIComponent(name)}&contact=${encodeURIComponent(contact)}&places=${places}&comments=${encodeURIComponent(comments)}`
        })
            .then(response => response.json())
            .then(data => {
                message.innerHTML = `<div class="alert ${data.success ? 'alert-success' : 'alert-danger'}">${data.message}</div>`;
                if (data.success) setTimeout(() => window.location.href = '../profile.html', 2000);
            })
            .catch(error => {
                console.error('Помилка:', error);
                message.innerHTML = '<div class="alert alert-danger">Помилка при бронюванні.</div>';
            });
    });

    updateAuthButton();
});