document.addEventListener('DOMContentLoaded', () => {
    const userInfo = document.getElementById('userInfo');
    const bookingHistory = document.getElementById('bookingHistory');
    const backButton = document.getElementById('backButton');
    const authNavItem = document.getElementById('authNavItem');
    const adminNavItem = document.getElementById('adminNavItem');
    const userId = sessionStorage.getItem('user_id');
    const currentDate = new Date('2025-05-25T12:45:00');

    if (!userId) {
        window.location.href = '../auth.html';
        return;
    }

    function updateAuthButton() {
        const role = sessionStorage.getItem('role');
        authNavItem.innerHTML = userId ?
            '<button id="logoutButton" class="btn btn-danger nav-link">Вийти</button>' :
            '<a class="nav-link" href="../auth.html">Увійти/Зареєструватися</a>';
    }

    authNavItem.addEventListener('click', (e) => {
        if (e.target.id === 'logoutButton') {
            sessionStorage.removeItem('user_id');
            sessionStorage.removeItem('role');
            window.location.href = '../index.html';
        }
    });

    backButton.addEventListener('click', () => {
        window.history.back();
    });

    function cancelBooking(bookingId, eventDate, places) {
        const eventDateObj = new Date(eventDate);
        if (eventDateObj <= currentDate) {
            alert('Скасувати бронювання неможливо, оскільки захід уже відбувся.');
            return;
        }
        if (confirm('Ви впевнені, що хочете скасувати це бронювання?')) {
            const url = '../cancel_booking.php';
            console.log('Запит до:', url, 'з параметрами:', { bookingId, places });
            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `bookingId=${bookingId}&places=${places}`
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! Status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Відповідь сервера:', data);
                    if (data.success) {
                        alert('Бронювання скасовано!');
                        fetchProfileData();
                    } else {
                        alert(data.message || 'Помилка при скасуванні.');
                    }
                })
                .catch(error => {
                    console.error('Помилка:', error);
                    alert('Помилка при скасуванні. Перевірте консоль.');
                });
        }
    }

    function fetchProfileData() {
        const url = `../profile.php?userId=${userId}`;
        console.log('Запит до:', url);
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Отримані дані:', data);
                if (data.error) {
                    userInfo.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
                    bookingHistory.innerHTML = '';
                    return;
                }
                userInfo.innerHTML = `<h4 class="text-xl font-semibold">Користувач: ${data.name} (${data.email})</h4>`;
                bookingHistory.innerHTML = data.bookings.map(booking => {
                    const eventDate = new Date(booking.date);
                    const canCancel = booking.status === 'pending' && eventDate > currentDate;
                    return `
                        <div class="col-md-6">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">${booking.eventTitle || 'Без назви'}</h5>
                                    <p class="card-text">Дата: ${eventDate.toLocaleString('uk-UA')}</p>
                                    <p class="card-text">Місця: ${booking.places || 0}</p>
                                    <p class="card-text">Статус: ${booking.status || 'Невідомо'}</p>
                                    ${canCancel ?
                            `<button class="btn btn-danger cancel-booking-btn" data-booking-id="${booking.id}" data-event-date="${booking.date}" data-places="${booking.places}">Скасувати</button>` :
                            ''}
                                </div>
                            </div>
                        </div>
                    `;
                }).join('');

                document.querySelectorAll('.cancel-booking-btn').forEach(button => {
                    button.addEventListener('click', () => {
                        const bookingId = button.getAttribute('data-booking-id');
                        const eventDate = button.getAttribute('data-event-date');
                        const places = button.getAttribute('data-places');
                        cancelBooking(bookingId, eventDate, places);
                    });
                });
            })
            .catch(error => {
                console.error('Помилка:', error);
                userInfo.innerHTML = '<div class="alert alert-danger">Помилка завантаження профілю. Перевірте консоль.</div>';
            });
    }

    updateAuthButton();
    fetchProfileData();
});