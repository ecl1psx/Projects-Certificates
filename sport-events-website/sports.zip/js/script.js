let currentPage = 1;
const eventsPerPage = 5;

function fetchEvents(page) {
    const eventsList = document.getElementById('eventsList');
    fetch(`../fetch_events.php?page=${page}&per_page=${eventsPerPage}`)
        .then(response => response.json())
        .then(data => {
            if (!data || !data.events || data.events.length === 0) {
                eventsList.innerHTML = '<div class="alert alert-warning">Жодного заходу не знайдено.</div>';
                setupPagination(0, page);
                return;
            }
            eventsList.innerHTML = '';
            data.events.forEach(event => {
                const isPast = new Date(event.date) < new Date();
                let status = isPast ? 'Захід завершився' : (event.availablePlaces > 0 ? 'Доступно' : 'Місця закінчилися');
                eventsList.innerHTML += `
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">${event.title}</h5>
                                <p class="card-text">Тип: ${event.sportType}</p>
                                <p class="card-text">Дата: ${new Date(event.date).toLocaleString('uk-UA')}</p>
                                <p class="card-text">Місце: ${event.location}</p>
                                <p class="card-text">Опис: ${event.description || 'Без опису'}</p>
                                <p class="card-text">Статус: <strong>${status}</strong></p>
                                <a href="event-details.html?eventId=${event.id}" class="btn btn-primary">Детальніше</a>
                            </div>
                        </div>
                    </div>
                `;
            });
            setupPagination(data.total || 0, page);
        })
        .catch(error => {
            console.error('Помилка:', error);
            eventsList.innerHTML = '<div class="alert alert-danger">Помилка завантаження заходів.</div>';
        });
}

function fetchFilteredEvents() {
    const sportType = document.getElementById('sportType').value;
    const date = document.getElementById('date').value;

    const params = new URLSearchParams();
    if (sportType) params.append('sportType', sportType);
    if (date) params.append('date', date);

    fetch(`../search.php?${params.toString()}`)
        .then(response => response.json())
        .then(data => {
            const eventsList = document.getElementById('eventsList');
            eventsList.innerHTML = '';
            document.getElementById('pagination').innerHTML = '';
            if (!data || data.length === 0) {
                eventsList.innerHTML = '<div class="alert alert-warning">Жодного заходу не знайдено.</div>';
                return;
            }

            data.forEach(event => {
                const isPast = new Date(event.date) < new Date();
                let status = isPast ? 'Захід завершився' : (event.availablePlaces > 0 ? 'Доступно' : 'Місця закінчилися');
                eventsList.innerHTML += `
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">${event.title}</h5>
                                <p class="card-text">Тип: ${event.sportType}</p>
                                <p class="card-text">Дата: ${new Date(event.date).toLocaleString('uk-UA')}</p>
                                <p class="card-text">Місце: ${event.location}</p>
                                <p class="card-text">Опис: ${event.description || 'Без опису'}</p>
                                <p class="card-text">Статус: <strong>${status}</strong></p>
                                <a href="event-details.html?eventId=${event.id}" class="btn btn-primary">Детальніше</a>
                            </div>
                        </div>
                    </div>
                `;
            });
        })
        .catch(error => {
            console.error('Помилка:', error);
            eventsList.innerHTML = '<div class="alert alert-danger">Помилка завантаження заходів.</div>';
        });
}

function setupPagination(total, current) {
    const pagination = document.getElementById('pagination');
    pagination.innerHTML = '';
    const totalPages = Math.ceil(total / eventsPerPage);
    if (totalPages === 0) return;
    for (let i = 1; i <= totalPages; i++) {
        const li = document.createElement('li');
        li.className = `page-item ${i === current ? 'active' : ''}`;
        li.innerHTML = `<a class="page-link" href="#" onclick="changePage(${i})">${i}</a>`;
        pagination.appendChild(li);
    }
}

function changePage(page) {
    currentPage = page;
    fetchEvents(page);
}

document.addEventListener('DOMContentLoaded', () => {
    const authNavItem = document.getElementById('authNavItem');
    const backButton = document.getElementById('backButton');

    document.getElementById('sportType').addEventListener('change', fetchFilteredEvents);
    document.getElementById('date').addEventListener('change', fetchFilteredEvents);
    document.getElementById('resetFilters').addEventListener('click', () => {
        document.getElementById('sportType').value = '';
        document.getElementById('date').value = '';
        fetchEvents(currentPage);
    });

    fetch('../fetch_sport_types.php')
        .then(res => res.json())
        .then(types => {
            const sportTypeSelect = document.getElementById('sportType');
            types.forEach(type => {
                sportTypeSelect.innerHTML += `<option value="${type.name}">${type.name}</option>`;
            });
        });

    function updateAuthButton() {
        const userId = sessionStorage.getItem('user_id');
        authNavItem.innerHTML = userId ?
            '<button id="logoutButton" class="btn btn-danger nav-link">Вийти</button>' :
            '<a class="nav-link" href="../auth.html">Увійти/Зареєструватися</a>';
    }

    authNavItem.addEventListener('click', (e) => {
        if (e.target.id === 'logoutButton') {
            sessionStorage.removeItem('user_id');
            sessionStorage.removeItem('role');
            window.location.href = '../index.html';
        }
    });

    backButton?.addEventListener('click', () => {
        window.history.back();
    });

    updateAuthButton();
    fetchEvents(currentPage);
});