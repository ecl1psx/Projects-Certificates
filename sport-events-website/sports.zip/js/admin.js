document.addEventListener('DOMContentLoaded', () => {
    const userId = sessionStorage.getItem('user_id');
    if (!userId || sessionStorage.getItem('role') !== 'administrator') {
        window.location.href = 'auth.html';
        return;
    }

    const createEventForm = document.getElementById('createEventForm');
    const createSportTypeForm = document.getElementById('createSportTypeForm');
    const eventMessage = document.getElementById('eventMessage');
    const sportTypeMessage = document.getElementById('sportTypeMessage');
    const eventList = document.getElementById('eventList');
    const bookingList = document.getElementById('bookingList');
    const authNavItem = document.getElementById('authNavItem');
    const backButton = document.getElementById('backButton');

    function updateAuthButton() {
        authNavItem.innerHTML = userId ?
            '<button id="logoutButton" class="btn btn-danger nav-link">Вийти</button>' : '';
    }

    authNavItem.addEventListener('click', (e) => {
        if (e.target.id === 'logoutButton') {
            sessionStorage.removeItem('user_id');
            sessionStorage.removeItem('role');
            window.location.href = 'index.html';
        }
    });

    backButton.addEventListener('click', () => {
        window.history.back();
    });

    window.loadEvents = function () {
        const url = 'search.php';
        console.log('Запит до:', url);
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Дані заходів:', data);
                eventList.innerHTML = data.length === 0 ? '<div class="alert alert-warning">Заходи відсутні.</div>' : data.map(event => `
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title">${event.title}</h5>
                            <p class="card-text">Тип: ${event.sportType}</p>
                            <p class="card-text">Дата: ${new Date(event.date).toLocaleString('uk-UA')}</p>
                            <p class="card-text">Місце: ${event.location}</p>
                            <p class="card-text">Доступні місця: ${event.availablePlaces}</p>
                            <button class="btn btn-warning mr-2 edit-event-btn" data-event-id="${event.id}" data-title="${event.title}" data-sport-type-id="${event.sportTypeId}" data-date="${event.date}" data-location="${event.location}" data-description="${event.description || ''}" data-available-places="${event.availablePlaces}" data-conditions="${event.conditions || ''}" data-organizer-contact="${event.organizerContact || ''}">Редагувати</button>
                            <button class="btn btn-danger delete-event-btn" data-event-id="${event.id}">Видалити</button>
                        </div>
                    </div>
                `).join('');

                document.querySelectorAll('.edit-event-btn').forEach(button => {
                    button.addEventListener('click', () => {
                        const eventId = button.getAttribute('data-event-id');
                        const title = button.getAttribute('data-title');
                        const sportTypeId = button.getAttribute('data-sport-type-id');
                        const date = button.getAttribute('data-date');
                        const location = button.getAttribute('data-location');
                        const description = button.getAttribute('data-description');
                        const availablePlaces = button.getAttribute('data-available-places');
                        const conditions = button.getAttribute('data-conditions');
                        const organizerContact = button.getAttribute('data-organizer-contact');
                        editEvent(eventId, title, sportTypeId, date, location, description, availablePlaces, conditions, organizerContact);
                    });
                });

                document.querySelectorAll('.delete-event-btn').forEach(button => {
                    button.addEventListener('click', () => {
                        const eventId = button.getAttribute('data-event-id');
                        deleteEvent(eventId);
                    });
                });
            })
            .catch(error => {
                console.error('Помилка завантаження заходів:', error);
                eventList.innerHTML = '<div class="alert alert-danger">Помилка завантаження заходів. Перевірте консоль.</div>';
            });
    }

    function editEvent(id, title, sportTypeId, date, location, description, availablePlaces, conditions, organizerContact) {
        const isoDate = new Date(date).toISOString().slice(0, 16);
        eventList.innerHTML = `
            <h2 class="text-2xl font-semibold mb-4">Редагувати захід</h2>
            <form id="editEventForm" class="p-6 rounded-lg mb-6">
                <input type="hidden" id="editEventId" value="${id}">
                <div class="mb-3">
                    <label for="editEventTitle" class="form-label">Назва</label>
                    <input type="text" class="form-control" id="editEventTitle" value="${title}" required>
                </div>
                <div class="mb-3">
                    <label for="editSportTypeId" class="form-label">Тип спорту</label>
                    <select class="form-control" id="editSportTypeId" required></select>
                </div>
                <div class="mb-3">
                    <label for="editEventDate" class="form-label">Дата</label>
                    <input type="datetime-local" class="form-control" id="editEventDate" value="${isoDate}" required>
                </div>
                <div class="mb-3">
                    <label for="editEventLocation" class="form-label">Місце</label>
                    <input type="text" class="form-control" id="editEventLocation" value="${location}" required>
                </div>
                <div class="mb-3">
                    <label for="editEventDescription" class="form-label">Опис</label>
                    <textarea class="form-control" id="editEventDescription" rows="3">${description}</textarea>
                </div>
                <div class="mb-3">
                    <label for="editEventConditions" class="form-label">Умови участі</label>
                    <textarea class="form-control" id="editEventConditions" rows="3">${conditions}</textarea>
                </div>
                <div class="mb-3">
                    <label for="editOrganizerContact" class="form-label">Контакт організатора</label>
                    <input type="text" class="form-control" id="editOrganizerContact" value="${organizerContact}">
                </div>
                <div class="mb-3">
                    <label for="editMaxPlaces" class="form-label">Максимальна кількість місць</label>
                    <input type="number" class="form-control" id="editMaxPlaces" value="${availablePlaces}" required>
                </div>
                <button type="submit" class="btn btn-primary mr-2">Зберегти</button>
                <button type="button" class="btn btn-secondary" onclick="loadEvents()">Скасувати</button>
            </form>
        `;
        fetch('fetch_sport_types.php')
            .then(response => response.json())
            .then(data => {
                const sportTypeSelect = document.getElementById('editSportTypeId');
                sportTypeSelect.innerHTML = '<option value="">Виберіть тип спорту</option>';
                data.forEach(type => {
                    sportTypeSelect.innerHTML += `<option value="${type.id}" ${type.id == sportTypeId ? 'selected' : ''}>${type.name}</option>`;
                });
            });
    }

    eventList.addEventListener('submit', (e) => {
        if (e.target.id === 'editEventForm') {
            e.preventDefault();

            const id = document.getElementById('editEventId').value;
            const title = document.getElementById('editEventTitle').value;
            const sportTypeId = document.getElementById('editSportTypeId').value;
            const date = document.getElementById('editEventDate').value;
            const location = document.getElementById('editEventLocation').value;
            const description = document.getElementById('editEventDescription').value;
            const conditions = document.getElementById('editEventConditions').value;
            const organizerContact = document.getElementById('editOrganizerContact').value;
            const maxPlaces = document.getElementById('editMaxPlaces').value;

            fetch('update_event.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `id=${id}&title=${encodeURIComponent(title)}&sportTypeId=${sportTypeId}&date=${encodeURIComponent(date)}&location=${encodeURIComponent(location)}&description=${encodeURIComponent(description)}&conditions=${encodeURIComponent(conditions)}&organizerContact=${encodeURIComponent(organizerContact)}&maxPlaces=${maxPlaces}`
            })
                .then(response => response.json())
                .then(data => {
                    eventMessage.innerHTML = `<div class="alert ${data.success ? 'alert-success' : 'alert-danger'}">${data.message}</div>`;
                    if (data.success) {
                        setTimeout(() => {
                            eventMessage.innerHTML = '';
                            loadEvents();
                        }, 2000);
                    }
                })
                .catch(error => {
                    console.error('Помилка при оновленні заходу:', error);
                    eventMessage.innerHTML = '<div class="alert alert-danger">Помилка оновлення заходу. Перевірте консоль.</div>';
                });
        }
    });

    function deleteEvent(id) {
        if (confirm('Ви впевнені, що хочете видалити цей захід?')) {
            fetch('delete_event.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `id=${id}`
            })
                .then(response => response.json())
                .then(data => {
                    eventMessage.innerHTML = `<div class="alert ${data.success ? 'alert-success' : 'alert-danger'}">${data.message}</div>`;
                    if (data.success) {
                        setTimeout(() => {
                            eventMessage.innerHTML = '';
                            loadEvents();
                        }, 2000);
                    }
                });
        }
    }

    fetch('fetch_sport_types.php')
        .then(response => response.json())
        .then(data => {
            const sportTypeSelect = document.getElementById('sportTypeId');
            data.forEach(type => {
                sportTypeSelect.innerHTML += `<option value="${type.id}">${type.name}</option>`;
            });
        });

    createEventForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const title = document.getElementById('eventTitle').value;
        const sportTypeId = document.getElementById('sportTypeId').value;
        const date = document.getElementById('eventDate').value;
        const location = document.getElementById('eventLocation').value;
        const description = document.getElementById('eventDescription').value;
        const conditions = document.getElementById('eventConditions').value;
        const organizerContact = document.getElementById('organizerContact').value;
        const maxPlaces = document.getElementById('maxPlaces').value;

        const url = 'create_event.php';
        console.log('Запит до:', url, 'з параметрами:', { title, sportTypeId, date, location, description, conditions, organizerContact, maxPlaces });
        fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `title=${encodeURIComponent(title)}&sportTypeId=${sportTypeId}&date=${encodeURIComponent(date)}&location=${encodeURIComponent(location)}&description=${encodeURIComponent(description)}&conditions=${encodeURIComponent(conditions)}&organizerContact=${encodeURIComponent(organizerContact)}&maxPlaces=${maxPlaces}`
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.text();
            })
            .then(text => {
                console.log('Відповідь сервера (текст):', text);
                const data = JSON.parse(text);
                console.log('Розібрані дані:', data);
                eventMessage.innerHTML = `<div class="alert ${data.success ? 'alert-success' : 'alert-danger'}">${data.message}</div>`;
                if (data.success) {
                    setTimeout(() => {
                        window.location.href = 'index.html';
                    }, 2000);
                }
            })
            .catch(error => {
                console.error('Помилка створення заходу:', error);
                eventMessage.innerHTML = '<div class="alert alert-danger">Помилка створення заходу. Перевірте консоль.</div>';
            });
    });

    createSportTypeForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('sportTypeName').value;

        fetch('create_sport_type.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `name=${encodeURIComponent(name)}`
        })
            .then(response => response.json())
            .then(data => {
                sportTypeMessage.innerHTML = `<div class="alert ${data.success ? 'alert-success' : 'alert-danger'}">${data.message}</div>`;
                if (data.success) {
                    fetch('fetch_sport_types.php')
                        .then(response => response.json())
                        .then(data => {
                            const sportTypeSelect = document.getElementById('sportTypeId');
                            sportTypeSelect.innerHTML = '<option value="">Виберіть тип спорту</option>';
                            data.forEach(type => {
                                sportTypeSelect.innerHTML += `<option value="${type.id}">${type.name}</option>`;
                            });
                        });
                }
            });
    });

    const bookingsUrl = 'admin_bookings.php';
    console.log('Запит до:', bookingsUrl);
    fetch(bookingsUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Дані бронювань:', data);
            bookingList.innerHTML = data.length === 0 ? '<div class="alert alert-warning">Бронювання відсутні.</div>' : data.map(booking => `
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title">${booking.eventTitle}</h5>
                        <p class="card-text">Користувач: ${booking.userName}</p>
                        <p class="card-text">Контакт: ${booking.contact}</p>
                        <p class="card-text">Місця: ${booking.places}</p>
                        <p class="card-text">Дата: ${new Date(booking.createdAt).toLocaleString('uk-UA')}</p>
                        <p class="card-text">Статус: ${booking.status}</p>
                    </div>
                </div>
            `).join('');
        })
        .catch(error => {
            console.error('Помилка завантаження бронювань:', error);
            bookingList.innerHTML = '<div class="alert alert-danger">Помилка завантаження бронювань. Перевірте консоль.</div>';
        });

    updateAuthButton();
    loadEvents();
});