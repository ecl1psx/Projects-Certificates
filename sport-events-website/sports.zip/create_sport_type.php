<?php
header('Content-Type: application/json');
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'administrator') {
    echo json_encode(['success' => false, 'message' => 'Доступ заборонено!']);
    exit;
}

$name = $_POST['name'];

$sql = "INSERT INTO sport_types (name) VALUES (?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $name);
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Тип спорту створено!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Помилка створення типу спорту!']);
}

$conn->close();
?>