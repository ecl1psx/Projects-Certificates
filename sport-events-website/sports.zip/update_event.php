<?php
header('Content-Type: application/json');
require_once 'db_connect.php';

try {
    $id = $_POST['id'] ?? null;
    $title = $_POST['title'] ?? '';
    $sportTypeId = $_POST['sportTypeId'] ?? null;
    $date = $_POST['date'] ?? '';
    $location = $_POST['location'] ?? '';
    $description = $_POST['description'] ?? '';
    $conditions = $_POST['conditions'] ?? '';
    $organizerContact = $_POST['organizerContact'] ?? '';
    $maxPlaces = $_POST['maxPlaces'] ?? 0;

    if ($id === null || $sportTypeId === null || $date === '' || $location === '' || $maxPlaces <= 0) {
        echo json_encode(['success' => false, 'message' => 'Недостатньо даних для оновлення заходу']);
        exit;
    }

    $checkSql = "SELECT availablePlaces FROM events WHERE id = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("i", $id);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Захід не знайдено']);
        exit;
    }
    $row = $result->fetch_assoc();
    $currentPlaces = $row['availablePlaces'];

    $updateSql = "UPDATE events SET title = ?, sportTypeId = ?, date = ?, location = ?, description = ?, conditions = ?, organizerContact = ?, maxPlaces = ?, availablePlaces = ? WHERE id = ?";
    $stmt = $conn->prepare($updateSql);
    $bookedSql = "SELECT SUM(places) AS totalBooked FROM bookings WHERE eventId = ?";
    $bookedStmt = $conn->prepare($bookedSql);
    $bookedStmt->bind_param("i", $id);
    $bookedStmt->execute();
    $bookedResult = $bookedStmt->get_result();
    $bookedRow = $bookedResult->fetch_assoc();
    $booked = (int)($bookedRow['totalBooked'] ?? 0);

    $availablePlaces = max($maxPlaces - $booked, 0);

    $stmt->bind_param("sissssiiii", $title, $sportTypeId, $date, $location, $description, $conditions, $organizerContact, $maxPlaces, $availablePlaces, $id);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Захід оновлено успішно']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Помилка оновлення заходу: ' . $conn->error]);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Помилка: ' . $e->getMessage()]);
}

$conn->close();
?>